package com.gomeplus.oversea.bs.common.exception.entity;

import lombok.Data;

/**
 * Created by shangshengfang on 2017/2/17.
 */
@Data
public class FullError {
    private String message;
    private Error error;
}
