package com.gomeplus.oversea.bs.common.exception;

/**
 * Created by zhaozhou on 2016/10/19.
 */
public class RESTfull4xxBaseException extends RestfullBaseException {
    public RESTfull4xxBaseException(String message) {
        super(message);
    }
}
