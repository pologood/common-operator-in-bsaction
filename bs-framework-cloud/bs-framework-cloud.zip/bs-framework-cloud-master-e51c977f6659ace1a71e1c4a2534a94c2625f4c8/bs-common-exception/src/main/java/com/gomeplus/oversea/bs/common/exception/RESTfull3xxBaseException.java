package com.gomeplus.oversea.bs.common.exception;

/**
 * Created by zhaozhou on 2016/10/19.
 */
public class RESTfull3xxBaseException extends RestfullBaseException {
    public RESTfull3xxBaseException(String message) {
        super(message);
    }
}
