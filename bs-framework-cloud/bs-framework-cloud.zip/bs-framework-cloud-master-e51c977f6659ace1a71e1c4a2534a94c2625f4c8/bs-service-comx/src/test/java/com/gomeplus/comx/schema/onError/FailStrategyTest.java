package com.gomeplus.comx.schema.onError;

import org.junit.Test;

/**
 * Created by xue on 2/22/17.
 */
public class FailStrategyTest {
    @Test
    public void test1() {

    }
}
