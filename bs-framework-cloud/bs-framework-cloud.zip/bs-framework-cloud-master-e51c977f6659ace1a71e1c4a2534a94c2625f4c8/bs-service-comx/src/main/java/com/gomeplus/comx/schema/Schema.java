package com.gomeplus.comx.schema;

import com.gomeplus.comx.utils.config.Config;

/**
 * Created by xue on 12/8/16.
 */
public class Schema {
    private Config conf;

    public Schema(Config conf){
        this.conf = conf;
    }




















    public Config getConf() {
        return conf;
    }

    public void setConf(Config conf) {
        this.conf = conf;
    }
}
