package com.gomeplus.comx.schema.datadecor.decors;


import com.gomeplus.comx.utils.config.ConfigException;

/**
 * Created by xue on 12/20/16.
 */
public class UnknownDecorTypeException extends ConfigException {
    public UnknownDecorTypeException(String message) {
        super(message);
    }
}
