package com.gomeplus.comx.utils.log;

/**
 * Created by xue on 12/8/16.
 */
public class ComxLoggerFactory {
    public static ComxLogger getLogger() {
        return new ComxLogger();
    }
}
