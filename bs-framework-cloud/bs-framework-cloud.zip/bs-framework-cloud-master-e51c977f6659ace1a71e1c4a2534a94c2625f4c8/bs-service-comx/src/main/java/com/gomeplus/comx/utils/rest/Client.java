package com.gomeplus.comx.utils.rest;

/**
 * Created by xue on 12/24/16.
 */
public class Client {
    public void test() {};
}
