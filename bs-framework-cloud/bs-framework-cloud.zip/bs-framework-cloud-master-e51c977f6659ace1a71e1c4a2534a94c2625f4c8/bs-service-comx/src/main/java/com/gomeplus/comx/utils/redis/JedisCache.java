package com.gomeplus.comx.utils.redis;

/**
 * Created by xue on 1/3/17.
 * master-slave jedis instance, TODO 暂时不需要
 */
public class JedisCache {
}
