#boot
    -   封装requestMessage 是否在boot 中处理
    -   业务逻辑  bootstrap
    -   handler
    -   read comx.conf.json
#others
    -   Context 是同一个请求中可以有多个的
    -   
    
