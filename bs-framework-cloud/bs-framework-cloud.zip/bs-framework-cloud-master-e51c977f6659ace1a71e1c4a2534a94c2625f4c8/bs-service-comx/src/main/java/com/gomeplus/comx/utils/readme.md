#readme utils
提供
    1, cache 类封装
    2, 日志类封装
    3, config类封装 (json)

抛出异常不直接到用户