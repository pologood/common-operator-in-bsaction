package com.gomeplus.comx.schema.datadecor.decors;

import com.gomeplus.comx.context.Context;
import com.gomeplus.comx.schema.datadecor.DecorException;
import com.gomeplus.comx.source.Source;
import com.gomeplus.comx.source.SourceException;
import com.gomeplus.comx.utils.config.Config;
import com.gomeplus.comx.utils.config.ConfigException;

import java.util.*;

import static java.lang.Boolean.TRUE;

/**
 * Created by xue on 12/20/16.
 */
public class EachDecor extends AbstractDecor implements RefJsonPath{
    public static final String FIELD_SOURCE         = "source";
    public static final String FIELD_FIELD          = "field";
    public static final String FIELD_OVERRIDE       = "override";

    protected Boolean override;
    protected Source source;
    protected String field;

    public EachDecor(Config conf){
        super(conf);
    }
    public String getType(){ return AbstractDecor.TYPE_EACH;}



    public void doDecorate(Object data, Context context) throws ConfigException, SourceException{
        List matchedNodes = getMatchedNodes(conf, data, context);
        source = new Source(conf.rsub(EachDecor.FIELD_SOURCE));
        field  = conf.str(EachDecor.FIELD_FIELD,  "");
        override = conf.bool(FIELD_OVERRIDE, TRUE);

        // TODO 针对简单source load 情况， 内部应不会产生数据冲突， 我们可以采用 parallel 或者 fiber 形式都可以
        //for (Object ref: matchedNodes) {
        //    this.decorateOneNode(ref, data, context);
        //}
        // ref 并不一定是一个map, 但 map 并非 map 的时候，map 将不能够新增
        ArrayList<Exception> exceptions = new ArrayList<>();
        matchedNodes.parallelStream().forEach(ref -> {
            try {
                decorateOneNode(ref, data, context);
            } catch(Exception ex) {
                exceptions.add(ex);
            }
        });
        if (exceptions.isEmpty()) return;
        Exception ex = exceptions.get(0);
        if (ex instanceof SourceException) throw (SourceException) ex;
        throw new SourceException(exceptions.get(0));
    }


    /**
     * 调用Source loadData; TODO 修正逻辑
     * @param ref
     * @param data
     * @param context
     */
    public void decorateOneNode(Object ref, Object data, Context context) throws ConfigException, SourceException{
        HashMap<String, Object> vars = new HashMap<String, Object>(){{
                put("ref", ref);
                put("data", data);
            }
        };
        Object loaded = source.loadData(context, vars);
        if (null == loaded) return;

        Map obj = field.isEmpty()? (Map) loaded: new HashMap<String, Object>(){{put(field, loaded);}};
        if (ref instanceof Map) {
            for (Object key: obj.keySet()) {
                if (!override && ((Map) ref).containsKey(key)) continue;
                ((Map)ref).put(key, obj.get(key));
            }
        }
    }
}