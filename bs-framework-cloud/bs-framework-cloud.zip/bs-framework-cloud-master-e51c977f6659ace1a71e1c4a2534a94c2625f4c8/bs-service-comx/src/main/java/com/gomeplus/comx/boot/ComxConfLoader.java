package com.gomeplus.comx.boot;

import com.gomeplus.comx.source.sourcebase.SourceBaseFactory;
import com.gomeplus.comx.utils.redis.AbstractCache;
import com.gomeplus.comx.utils.redis.CacheFactory;
import com.gomeplus.comx.utils.config.Config;
import com.gomeplus.comx.utils.config.ConfigException;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by xue on 12/16/16.
 * 在服务启动时加载配置
 */
@Slf4j
public class ComxConfLoader {
    private static boolean              initialized = false;
    private static String               COMX_HOME;
    private static Config               comxConf;
    private static SourceBaseFactory    sourceBaseFactory;
    private static AbstractCache        cache;
    private static String               urlPrefix;



    private static final String FIELD_URL_PREFIX    = "urlPrefix";
    private static final String FIELD_CACHE         = "cache";

    static {
        Properties prop = new Properties();
        InputStream in = ComxConfLoader.class.getClassLoader().getResourceAsStream("comx.properties");
        try {
            prop.load(in);
        } catch (IOException e) {
            log.error("fail to load properties!", e);
            throw new RuntimeException(e);
        }
        COMX_HOME = prop.getProperty("comx_home");
    }


    // 提供更新方法 TODO
    public static Config load()  throws ConfigException{
        if (!initialized) {
            initialize();
        }
        return comxConf;
    }

    public static void initialize()  throws ConfigException{
        comxConf            = com.gomeplus.comx.utils.config.Loader.fromJsonFile(COMX_HOME + "/comx.conf.json");
        sourceBaseFactory   = SourceBaseFactory.fromConf(comxConf);
        urlPrefix           = comxConf.rstr(FIELD_URL_PREFIX);
        Config cacheConf    = comxConf.sub(FIELD_CACHE);
        cache               = CacheFactory.fromConf(cacheConf);
        initialized         = true;
    }






    public static String getUrlPrefix() {
        return urlPrefix;
    }

    public static AbstractCache getCache() {return cache;}

    public static String getComxHome() {
        return COMX_HOME;
    }

    public static Config getComxConf() {
        return comxConf;
    }

    public static SourceBaseFactory getSourceBaseFactory() {
        return sourceBaseFactory;
    }
}
