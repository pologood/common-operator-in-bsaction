package com.gomeplus.comx.context;

import com.gomeplus.comx.utils.rest.RequestMessage;

/**
 * Created by xue on 12/16/16.
 * 因为业务变更，这里不再处理，不过预留类
 */
public class User {
    /**
     * @param request
     */
    public User(RequestMessage request) {
    }
}
