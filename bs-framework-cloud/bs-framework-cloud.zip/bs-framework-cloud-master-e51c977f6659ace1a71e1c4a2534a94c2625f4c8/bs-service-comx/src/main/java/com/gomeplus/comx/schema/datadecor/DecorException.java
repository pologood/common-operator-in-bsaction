package com.gomeplus.comx.schema.datadecor;

/**
 * Created by xue on 1/12/17.
 */
public class DecorException extends Exception{
    public DecorException(String message) {
        super(message);
    }
    public DecorException(Throwable throwable) {
        super(throwable);
    }
}
