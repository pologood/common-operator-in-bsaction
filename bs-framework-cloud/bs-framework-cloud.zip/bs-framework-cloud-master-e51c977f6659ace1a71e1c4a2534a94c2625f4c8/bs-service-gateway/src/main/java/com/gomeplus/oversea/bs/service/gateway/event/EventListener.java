package com.gomeplus.oversea.bs.service.gateway.event;

/**
 * Created by neowyp on 2016/7/9.
 * Author   : wangyunpeng
 * Date     : 2016/7/9
 * Time     : 9:15
 * Version  : V1.0
 * Desc     : 事件监听器接口类，用于向事件总线注册时应用
 * @see EventDispatcher
 */
public interface EventListener {
}
