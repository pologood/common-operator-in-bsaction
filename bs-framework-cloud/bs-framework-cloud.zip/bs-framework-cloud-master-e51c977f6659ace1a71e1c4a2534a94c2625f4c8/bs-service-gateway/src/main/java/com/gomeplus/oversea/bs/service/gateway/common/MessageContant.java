package com.gomeplus.oversea.bs.service.gateway.common;

/**
 * Created by shangshengfang on 2017/4/6.
 */
public class MessageContant {
    //公参校验失败
    public static String publicParamInvalide="public parameters validated fail.";
    /*参数校验失败，包括query和body*/
    public static String paramInvalide="parameters validated fail.";
    /*请求在swagger中未定义*/
    public static String invalidRequest="invalid request";
}
