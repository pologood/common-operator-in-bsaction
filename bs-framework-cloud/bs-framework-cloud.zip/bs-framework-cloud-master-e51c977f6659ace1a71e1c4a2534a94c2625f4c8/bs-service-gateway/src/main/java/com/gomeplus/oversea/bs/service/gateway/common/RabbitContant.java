package com.gomeplus.oversea.bs.service.gateway.common;

/**
 * Created by shangshengfang on 2017/2/28.
 */
public class RabbitContant {
    public static String RABBIT_EXCHANGE_ITEM_LOG="bi.topic";
    public static String RABBIT_ROUTINGKEY_ITEM_LOG="item.log";

    public static String RABBIT_EXCHANGE_TOKEN_SUCCESS="taskStatic.topic";
    public static String RABBIT_ROUTINGKEY_TOKEN_SUCCESS="taskStatic.routingKey";

}
